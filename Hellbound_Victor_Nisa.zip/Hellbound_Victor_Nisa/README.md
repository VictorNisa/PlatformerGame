# Hellbound

## Description

Game about platforming very good.

## Key Features

 - Dash
 - Jump
 - Platforms
 
## Controls

 - WASD to move
 - Left Shift to dash

## Developer

 - Victor Nisa

## License

This project is licensed under an unmodified MIT license, which is an OSI-certified license that allows static linking with closed source software. Check [LICENSE](LICENSE) for further details.

{AdditionalLicenses}
