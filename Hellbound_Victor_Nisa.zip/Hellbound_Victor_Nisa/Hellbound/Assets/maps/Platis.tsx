<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="Platis" tilewidth="32" tileheight="32" tilecount="666" columns="16">
 <image source="Platis.png" width="512" height="128"/>
 <tile id="102">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="197">
  <objectgroup draworder="index">
   <object id="12" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
</tileset>
